Saga Edition - Versão Completa
====================================

Este pacote contém o site COMPLETO com a ficha interativa funcional.

Como usar no Webflow:
1. Crie um novo site em branco.
2. Abra a página inicial.
3. Adicione um bloco EMBED.
4. Copie TODO o conteúdo de index.html para dentro do Embed.
5. Publique.

Seu site estará funcionando 100%.
